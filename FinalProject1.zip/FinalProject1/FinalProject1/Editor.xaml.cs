﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalProject1
{
    /// <summary>
    /// Interaction logic for Editor.xaml
    /// </summary>
    public partial class Editor : Window
    {
        Customer[] array = new Customer[100];
        public Editor()
        {
            InitializeComponent();
        }
        public Editor(Customer [] c)
        {
            InitializeComponent();
            array = c;
        }
        
        private Customer searchCustomer(int j)
        {
            for (int i = 0; i < 100; i++)
            {
                if (array[i].UserId == j)
                {
                    return array[i];
                }
            }

            return new Customer(0, "", "", "", 0);
        }

        public void searchButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer x = searchCustomer(Convert.ToInt32(IDBox.Text));
                NameBox.Text = x.Name;
                AddressBox.Text = x.Address;
                CityBox.Text = x.City;
                string s= x.phoneToString();
               PhoneBox.Text = s;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void addButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Confirm adding " + NameBox.Text + "?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    int i = Convert.ToInt32(IDBox.Text);
                    int p = Convert.ToInt32(PhoneBox.Text);
                    Customer x = new Customer(i, NameBox.Text, AddressBox.Text, CityBox.Text, p);
                    int loc = find(0);
                    array[loc] = x;
                    new Window2(array).Show();
                    Close();                 
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
        private int find (int i)
        {
            int x = 3;
            for (int z=0;z<100;z++)
            {
                if (array[z].UserId == i)
                {
                    return z;
                }
            }
            return x;
        }
        public void editButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Confirm editing " + NameBox.Text + "?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    int i = Convert.ToInt32(IDBox.Text);
                    int p = Convert.ToInt32(PhoneBox.Text);
                    Customer x = new Customer(i, NameBox.Text, AddressBox.Text, CityBox.Text, p);
                    int loc = find(i);
                    array[loc] = x;
                    new Window2(array).Show();
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        public void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Confirm deleting " + NameBox.Text + "?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    int loc=find(Convert.ToInt32(IDBox.Text));
                    array[loc] = new Customer(0, "", "", "", 0);
                    new Window2(array).Show();
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
