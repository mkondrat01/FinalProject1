﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject1
{
    public class Customer
    {
        public Customer (int i,string n, string a, string c,int p)
        {
            UserId = i;
            Name = n;
            Address = a;
            City = c;
            Phone = p;
        }
        
        public int UserId
        {
            get;set;
        }
        public string Name
        {
            get; set;
        }
        public string Address
        {
            get; set;
        }

        public string City
        {
            get; set;
        }
        public int Phone
        {
            get; set;
        }
        public string toString()
        {
            return (UserId + ", " + Name + ", " + Address + ", " + City + ", " + Phone);
        }
       
        public string idToString ()
        {
            return Convert.ToString(UserId);
        }
        public string nameToString ()
        {
            return Name;
        }
        public string addressToString()
        {
            return Address;
        }
        public string cityToString()
        {
            return City;
        }

        public string phoneToString()
        {
            return Convert.ToString(Phone);
        }

        public Boolean equals(Customer c)
        {
            return (UserId == c.UserId);
        }

    }
}
