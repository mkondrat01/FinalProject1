﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalProject1
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        Customer[] array = new Customer[100];
        public Window2()
        {
            InitializeComponent();
            array = new Customer[100];
            refresh();
        }
        public Window2 (Customer [] c)
        {
            InitializeComponent();
            array = c;
            refresh();
            
        }
        
        private void refreshButton_Click(object sender, RoutedEventArgs e)
        {
            refresh();
        }
        public void refresh ()
        {
            List<Customer> list = new List<Customer>(array);
            grid.DataContext = list;
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            new Editor(array).Show();
            Close();
        }
      

    }
}
