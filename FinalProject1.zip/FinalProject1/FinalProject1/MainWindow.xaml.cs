﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace FinalProject1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Customer[] array = new Customer[100];
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (tBox.Text == "admin" && pBox.Password == "1234")
            {
                iFill();
                new Window2(array).Show();
                Close();
            }
        }
        public void iFill()
        {
            array[0] = new Customer(11111, "Bob Smith", "145 Elm St.", "Paris", 124343);
            array[1] = new Customer(1234, "Tom Richard", "543 Gill Lane", "Lyon", 21331432);
            array[2] = new Customer(55445, "Tob Ricsmith", "56545 Fill St.", "Amsterdam", 124343);
            for (int i = 3; i < 100; i++)
            {
                array[i] = new Customer(0, "", "", "", 0);
            }
        }
       
    }
}
